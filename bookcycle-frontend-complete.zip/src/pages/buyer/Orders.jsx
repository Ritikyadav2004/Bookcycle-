import React from 'react';
import { Package, MapPin, Search } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { formatPrice } from '../../utils/formatters';

const BuyerOrders = () => {
  const orders = [
    { id: 'ORD-1092', date: 'Oct 12, 2026', total: 450, status: 'Delivered', items: [
      { title: 'Mathematics Class 12', author: 'NCERT', price: 150 },
      { title: 'Physics Class 12', author: 'NCERT', price: 180 }
    ]},
    { id: 'ORD-1085', date: 'Sep 28, 2026', total: 320, status: 'Processing', items: [
      { title: 'Chemistry Class 11', author: 'NCERT', price: 160 }
    ]}
  ];

  return (
    <div className="pb-12">
      <h1 className="text-3xl font-serif font-bold text-forest mb-2">My Orders</h1>
      <p className="text-mutedText mb-8">View and track your previous purchases.</p>

      <div className="space-y-6">
        {orders.map((order, index) => (
          <div key={index} className="bg-white rounded-3xl p-6 shadow-sm border border-forest/5">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-forest/5 pb-4 mb-4 gap-4">
              <div>
                <h3 className="font-bold text-darkText">Order #{order.id}</h3>
                <p className="text-sm text-mutedText">Placed on {order.date}</p>
              </div>
              <div className="flex items-center gap-4">
                <span className="font-bold text-forest">{formatPrice(order.total)}</span>
                <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                  order.status === 'Delivered' ? 'bg-emerald/10 text-emerald' : 'bg-amber/20 text-amber-dark'
                }`}>
                  {order.status}
                </span>
              </div>
            </div>
            
            <div className="space-y-3">
              {order.items.map((item, i) => (
                <div key={i} className="flex justify-between items-center bg-warmWhite p-3 rounded-xl">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-white rounded flex items-center justify-center border border-forest/5">
                      <Package size={16} className="text-mutedText" />
                    </div>
                    <div>
                      <h4 className="text-sm font-semibold text-darkText">{item.title}</h4>
                      <p className="text-xs text-mutedText">by {item.author}</p>
                    </div>
                  </div>
                  <span className="text-sm font-medium text-forest">{formatPrice(item.price)}</span>
                </div>
              ))}
            </div>
            
            <div className="mt-4 pt-4 border-t border-forest/5 flex justify-end gap-3">
              <button
                onClick={() => toast.success(`Invoice ready for ${order.id}`)}
                className="px-4 py-2 text-sm font-semibold text-forest border border-forest/20 rounded-lg hover:bg-forest/5 transition-colors"
              >
                View Invoice
              </button>
              {order.status === 'Delivered' && (
                <button
                  onClick={() => toast.success(`Review form opened for ${order.id}`)}
                  className="px-4 py-2 text-sm font-semibold text-white bg-forest rounded-lg hover:bg-forest-dark transition-colors"
                >
                  Write Review
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BuyerOrders;
