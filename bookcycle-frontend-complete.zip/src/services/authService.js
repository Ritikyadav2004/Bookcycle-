import api from './api';
import { delay } from '../utils/helpers';

// Mock auth data to use until backend is ready
const mockAuthUser = {
  id: 'u123',
  name: 'John Doe',
  email: 'john@example.com',
  token: 'mock-jwt-token-xyz',
};

export const authService = {
  // Login as Buyer
  loginBuyer: async (credentials) => {
    // In production: return api.post('/auth/login-buyer', credentials);
    await delay(800);
    if (credentials.email === 'error@test.com') throw new Error('Invalid credentials');
    return { ...mockAuthUser, role: 'buyer', name: 'Buyer Test' };
  },

  // Login as Seller
  loginSeller: async (credentials) => {
    // In production: return api.post('/auth/login-seller', credentials);
    await delay(800);
    if (credentials.email === 'error@test.com') throw new Error('Invalid credentials');
    return { ...mockAuthUser, role: 'seller', name: 'Seller Test' };
  },

  // Login as Admin
  loginAdmin: async (credentials) => {
    // In production: return api.post('/auth/login-admin', credentials);
    await delay(800);
    return { ...mockAuthUser, role: 'admin', name: 'Admin User' };
  },

  // Register Buyer
  registerBuyer: async (data) => {
    // In production: return api.post('/auth/register-buyer', data);
    await delay(1000);
    return { ...mockAuthUser, role: 'buyer', ...data };
  },

  // Register Seller
  registerSeller: async (data) => {
    // In production: return api.post('/auth/register-seller', data);
    await delay(1000);
    return { ...mockAuthUser, role: 'seller', ...data };
  },

  // Forgot Password
  forgotPassword: async (email) => {
    // In production: return api.post('/auth/forgot-password', { email });
    await delay(800);
    return { message: 'Reset link sent if email exists.' };
  },

  // Reset Password
  resetPassword: async (data) => {
    // In production: return api.post('/auth/reset-password', data);
    await delay(800);
    return { message: 'Password reset successfully.' };
  },
};

export default authService;
