import { createResourceService, mockOrders } from './mockServiceFactory';

const orderService = createResourceService('order', mockOrders);

export default orderService;
